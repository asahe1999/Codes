﻿#region Headers

using CommonFunctions;
using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI.WebControls;

#endregion

#region Page

public partial class marketingstrat : System.Web.UI.Page
{
    #region Variable Declaration

    Common _common = new Common();
    SafeExecuter _safeExecuter = new SafeExecuter();
    clsDefault _clsDefault = new clsDefault();
    BindPage_Common _BindPage_Common = new BindPage_Common();
    List<clsQuestionAns> lstQuestionAns = new List<clsQuestionAns>();

    #endregion

    #region Page Load

    protected void Page_Load(object sender, EventArgs e)
    {
        string guid = _common.ConvertString(Request.QueryString["id"]);

        _BindPage_Common.BindPageLoad(Page, guid);
    }

    #endregion

    #region Bind

    protected void ddlOptions_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (((DropDownList)sender).AutoPostBack)
            _BindPage_Common.ddlOptions_SelectedIndexChanged(sender, gvQuestions);
        UpdatePanel1.Update();
    }

    protected void chkLstOptions_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (((CheckBoxList)sender).AutoPostBack)
            _BindPage_Common.chkLstOptions_SelectedIndexChanged(sender, gvQuestions);
        UpdatePanel1.Update();
    }

    protected void rblOptions_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (((RadioButtonList)sender).AutoPostBack)
            _BindPage_Common.rblOptions_SelectedIndexChanged(sender, gvQuestions);
        UpdatePanel1.Update();
    }

    protected void gvQuestions_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            _BindPage_Common.gvQuestions_RowDataBound(e.Row, null);
        }
    }

    #endregion

    #region Click

    protected void btnDownloadPDF_OnClick(object sender, EventArgs e)
    {
        _clsDefault.SaveDownloadClick(_common.ConvertString(Session["guid"]));
        if (Session["ContactId"] != null)
        {
            HttpBrowserCapabilities browser = HttpContext.Current.Request.Browser;
            string browserDetails = "Browser Family : " + browser.Browser + " | Browser Type : " + browser.Type + " | Is Mobile Browser : " + browser.IsMobileDevice.ToString() + " | Browser Platform : " + browser.Platform.ToString();
            string ContactID = _common.ConvertString(Session["ContactId"]);
          //  string MobileNo = txtMobileNo.Text;
            clsFormFields _clsFormFields = new clsFormFields
            {
                ContactID = _common.ConvertInt(ContactID),
                CTMID = _common.ConvertInt(hdnCTMID.Value),
                IPAddress = hdnIP.Value,
                BrowserDetails = browserDetails,
                Location = hdnLocation.Value,
                CPMID = _common.ConvertInt(hdnCPMID.Value),
                Extra1 = hdnExtra1.Value,
                Extra2 = hdnExtra2.Value,
                Extra3 = hdnExtra3.Value,

                FirstName = txtFirstName.Text,
                LastName = txtLastName.Text,
                Company = txtCompany.Text,
                // CompanyName = txtCompanyName.Text,
                JobTitle = txtJobTitle.Text,
                Email = txtEmail.Text,
                // Phone = txtPhoneNo.Text,
               // CompanySize = txtCompanySize.Text,
               // Address = txtAddress.Text,
                Country = ddlCountry.SelectedValue,
               // State = txtState.Text,
                //City = txtCity.Text,
               // PostalCode = txtPostalCode.Text,
                //AuthorityLevel = txtAuthorityLevel.Text,
                // Industry = ddlIndustry.SelectedValue,
                //Department = txtDepartment.Text,
                //NoOfEmployees = txtNoOfEmployees.Text,
                //Revenue = txtRevenue.Text,
                //JobFunction = txtJobFunction.Text,
                //Comments = txtComment.Text,
               // Province = txtProvince.Text,
               // JobLevel = ddlJobLevel.SelectedValue
            };
            _BindPage_Common.SaveClick(_clsFormFields, gvQuestions);
        }
        if (Session["AssetTypeID"] != null)
        {
            hdnSubmitted.Value = "true";
            string AssetTypeID = _common.ConvertString(Session["AssetTypeID"]);
            if (AssetTypeID == "1")
            {
                if (!string.IsNullOrEmpty(hdnPDFName.Value))
                    _BindPage_Common.LogAssetDetails(hdnPDFName.Value, true);

                _common.DownloadAsset(hdnPDFName.Value);
            }
            else if (AssetTypeID == "2")
            {
                hdnisAssetDownload.Value = "true";
                hdnAssetOpenInNewTab.Value = "true";
                if (!string.IsNullOrEmpty(hdnPDFName.Value))
                    _BindPage_Common.LogAssetDetails(hdnPDFName.Value, false);

                Utilities.Alert.ExecuteJqueryCommand("window.open('" + hdnPDFName.Value + "', '_blank')", this);
            }
            else
                _BindPage_Common.LogAssetDetails("None", false);
        }
    }

    #endregion

}

#endregion